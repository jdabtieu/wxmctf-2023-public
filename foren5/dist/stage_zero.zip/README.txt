Welcome to the Zip Gauntlet! Here, you'll test your forensics skills by solving five stages and unlocking nested zips until you get the flag!

To enter stage one, use the password "start".